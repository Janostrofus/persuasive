import 'package:flutter/material.dart';

class MemoryTraining extends StatefulWidget {
  const MemoryTraining({super.key});

  @override
  State<MemoryTraining> createState() => _MemoryTrainingState();
}

class _MemoryTrainingState extends State<MemoryTraining> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Memory Training"),
        centerTitle: true,
      ),
    );
  }
}
