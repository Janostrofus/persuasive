import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

class ProgressiveMuscleRelaxation extends StatefulWidget {
  const ProgressiveMuscleRelaxation({super.key});

  @override
  State<ProgressiveMuscleRelaxation> createState() =>
      _ProgressiveMuscleRelaxationState();
}

class _ProgressiveMuscleRelaxationState
    extends State<ProgressiveMuscleRelaxation> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isPlaying = false;

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> _playAudio() async {
    if (_isPlaying) {
      await _audioPlayer.pause();
    } else {
      await _audioPlayer.play(AssetSource('assets/PMR.mp3'));
    }

    setState(() {
      _isPlaying = !_isPlaying;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("PMR"),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: _playAudio,
              child: Text(_isPlaying ? 'Pause Audio' : 'Play Audio'),
            ),
            SizedBox(height: 16),
            Text(
              "Press the button to play or pause the Progressive Muscle Relaxation audio.",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
